using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using NAudio.Wave;

namespace WindowsAurora;

public partial class MainWindow : Window
{
    readonly string[] sceneNames = { "Neon Spectrum", "Cosmic Rings", "Aurora", "Oscilloscope", "Particle Storm", "Neon Tunnel", "Liquid Dreams", "Pulse" };
    readonly DispatcherTimer frameTimer = new() { Interval = TimeSpan.FromMilliseconds(33) };
    readonly DispatcherTimer rotationTimer = new();
    WasapiLoopbackCapture? capture;
    readonly object audioLock = new();
    float level;
    readonly float[] bands = new float[64];
    int scene;
    int oldScene;
    bool transitioning;
    DateTime transitionStart;
    bool showingA = true;
    bool fullscreen;
    volatile float sensitivityValue = 1.6f;
    readonly Stopwatch clock = Stopwatch.StartNew();
    readonly Random random = new();
    readonly Color[][] palettes = {
        new[]{Color.FromRgb(65,245,210),Color.FromRgb(126,85,255),Color.FromRgb(255,75,190)},
        new[]{Color.FromRgb(255,90,75),Color.FromRgb(255,190,65),Color.FromRgb(190,65,130)},
        new[]{Color.FromRgb(80,210,255),Color.FromRgb(175,235,255),Color.FromRgb(100,120,255)},
        new[]{Color.FromRgb(255,70,190),Color.FromRgb(130,90,255),Color.FromRgb(60,230,245)},
        new[]{Colors.White,Colors.LightGray,Colors.Gray}
    };
    public MainWindow()
    {
        InitializeComponent(); ScenePicker.ItemsSource = sceneNames; ScenePicker.SelectedIndex = 0;
        frameTimer.Tick += (_,_) => Render(); frameTimer.Start();
        rotationTimer.Tick += (_,_) => BeginRandomScene();
        Sensitivity.ValueChanged += (_,_) => sensitivityValue = (float)Sensitivity.Value;
        Interval.ValueChanged += (_,_) => IntervalText.Text = $"{Interval.Value:0}s";
        Fade.ValueChanged += (_,_) => FadeText.Text = $"{Fade.Value:0}s";
        Closed += (_,_) => StopCapture();
    }
    Color Ink(int i) => palettes[Math.Clamp(PalettePicker.SelectedIndex,0,4)][Math.Abs(i)%3];
    void ScenePicker_SelectionChanged(object sender, SelectionChangedEventArgs e) { if (ScenePicker.SelectedIndex < 0) return; scene = ScenePicker.SelectedIndex; transitioning = false; }
    void ModePicker_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        rotationTimer.Stop();
        if (ModePicker.SelectedIndex == 1) { rotationTimer.Interval = TimeSpan.FromSeconds(Interval.Value); rotationTimer.Start(); }
        else if (ModePicker.SelectedIndex == 2) Shuffle();
    }
    void Shuffle_Click(object sender, RoutedEventArgs e) => Shuffle();
    void Shuffle() { var allowed = SceneFilters.Children.OfType<CheckBox>().Select((check,index)=>new { check, index }).Where(item=>item.check.IsChecked==true).Select(item=>item.index).ToArray(); if(allowed.Length==0){Status.Text="Select at least one scene for shuffle";return;} oldScene = scene; int next = scene; if(allowed.Length==1) next=allowed[0]; else do { next=allowed[random.Next(allowed.Length)]; } while(next==scene); scene = next; ScenePicker.SelectedIndex = scene; StartTransition(); }
    void BeginRandomScene() { Shuffle(); rotationTimer.Interval = TimeSpan.FromSeconds(Interval.Value + Fade.Value); }
    void StartTransition() { transitionStart = DateTime.UtcNow; transitioning = true; }
    void Start_Click(object sender, RoutedEventArgs e) { if (capture != null) { StopCapture(); return; } try { capture = new WasapiLoopbackCapture(); capture.DataAvailable += AudioAvailable; capture.RecordingStopped += (_,__) => Dispatcher.Invoke(() => Status.Text = "Audio capture stopped"); capture.StartRecording(); StartButton.Content = "STOP AUDIO"; Status.Text = "Capturing Windows system output · No microphone"; } catch (Exception ex) { Status.Text = "Could not capture system audio: " + ex.Message; StopCapture(); } }
    void AudioAvailable(object? sender, WaveInEventArgs e)
    {
        var wf = capture!.WaveFormat; int bytesPerSample = wf.BitsPerSample / 8; int channels = wf.Channels; if (bytesPerSample < 2) return;
        int frames = e.BytesRecorded / (bytesPerSample * channels); if (frames == 0) return;
        var local = new float[64]; double sum = 0;
        for (int f=0; f<frames; f++) { float v=0; for(int ch=0;ch<channels;ch++){ int offset=(f*channels+ch)*bytesPerSample; float sample = bytesPerSample==4 ? BitConverter.ToSingle(e.Buffer,offset) : BitConverter.ToInt16(e.Buffer,offset)/32768f; v += sample/channels; } sum += v*v; int b=Math.Min(63,f*64/frames); local[b]=Math.Max(local[b],Math.Abs(v)); }
        lock(audioLock){ level=(float)Math.Sqrt(sum/frames)*sensitivityValue*5; for(int i=0;i<64;i++) bands[i]=Math.Clamp(local[i]*sensitivityValue*5,0,1); level=Math.Clamp(level,0,1); }
    }
    void StopCapture() { try { capture?.StopRecording(); capture?.Dispose(); } catch {} capture=null; StartButton.Content="START SYSTEM AUDIO"; Status.Text="Stopped · Audio is not saved"; lock(audioLock){level=0;Array.Clear(bands);} }
    void Fullscreen_Click(object sender,RoutedEventArgs e){fullscreen=!fullscreen;WindowStyle=fullscreen?WindowStyle.None:WindowStyle.SingleBorderWindow;WindowState=fullscreen?WindowState.Maximized:WindowState.Normal;}
    void Render()
    {
        double w=VisualHost.ActualWidth,h=VisualHost.ActualHeight;if(w<2||h<2)return; float l; float[] b; lock(audioLock){l=level;b=(float[])bands.Clone();}
        double t=transitioning?Math.Clamp((DateTime.UtcNow-transitionStart).TotalSeconds/Fade.Value,0,1):1; if(t>=1)transitioning=false;
        Canvas back=showingA?SceneB:SceneA, front=showingA?SceneA:SceneB; back.Children.Clear(); DrawScene(back,transitioning?oldScene:scene,w,h,b,l,clock.Elapsed.TotalSeconds);
        if(transitioning){front.Children.Clear();DrawScene(front,scene,w,h,b,l,clock.Elapsed.TotalSeconds);back.Opacity=1-t;front.Opacity=t;}else{front.Children.Clear();DrawScene(front,scene,w,h,b,l,clock.Elapsed.TotalSeconds);back.Opacity=0;front.Opacity=1;}
        if(transitioning&&t>=1)showingA=!showingA;
    }
    void DrawScene(Canvas c,int s,double w,double h,float[] b,float l,double time)
    {
        c.Width=w;c.Height=h; double cx=w/2,cy=h/2,m=Math.Min(w,h); var glow=new Ellipse{Width=m*.9,Height=m*.9,Fill=new RadialGradientBrush(Ink(1),Color.FromArgb(0,8,8,23)),Opacity=.2};Canvas.SetLeft(glow,cx-m*.45);Canvas.SetTop(glow,cy-m*.45);c.Children.Add(glow);
        switch(s){case 0: for(int i=0;i<64;i++){double bw=(w-50)/64.0-2,bh=Math.Max(3,b[i]*h*.72); AddRect(c,25+i*(bw+2),h-35-bh,bw,bh,Ink(i/22),.9,6);}break;
        case 1: for(int i=0;i<6;i++){double r=m*(.12+i*.065)+b[i*10]*35;AddEllipse(c,cx-r,cy-r,r*2,r*2,Ink(i),.8,2);}break;
        case 2: for(int k=0;k<4;k++){var p=new Polyline{Stroke=new SolidColorBrush(Ink(k)),StrokeThickness=14,Opacity=.45};for(int x=0;x<=100;x++){double xx=x*w/100,yy=cy+Math.Sin(x*.12+k*1.3)*h*.12+Math.Cos(x*.055+k)*h*.08-b[(x*64/101)]*h*.16+k*22;p.Points.Add(new Point(xx,yy));}c.Children.Add(p);}break;
        case 3: var wave=new Polyline{Stroke=new SolidColorBrush(Ink(0)),StrokeThickness=3.5,Effect=new System.Windows.Media.Effects.DropShadowEffect{Color=Ink(0),BlurRadius=18,ShadowDepth=0}};for(int x=0;x<w;x+=3){int i=Math.Clamp((int)(x*64/w),0,63);wave.Points.Add(new Point(x,cy+Math.Sin(x*.045)*b[i]*h*.38+Math.Sin(x*.012)*h*.05));}c.Children.Add(wave);break;
        case 4: for(int i=0;i<110;i++){double a=i*.31+i*.07,r=(.08+(i*0.618%1)*.38+l*.35)*m;AddEllipse(c,cx+Math.Cos(a)*r,cy+Math.Sin(a)*r,2+b[i%64]*8,2+b[i%64]*8,Ink(i/37),.8);}break;
        case 5: for(int i=0;i<14;i++){double z=1+i*.12+l*.15,rw=w*.12*z,rh=h*.12*z;AddRect(c,cx-rw,cy-rh,rw*2,rh*2,Ink(i),.8,2,transparent:true);}break;
        case 6: for(int k=0;k<3;k++){var p=new Polygon{Fill=new SolidColorBrush(Ink(k)),Opacity=.18};p.Points.Add(new Point(0,cy));for(int x=0;x<=100;x++){double xx=x*w/100,yy=cy+Math.Sin(x*.07+k*2)*h*.13+Math.Cos(x*.025+k)*h*.08-b[x*64/101]*h*.2;p.Points.Add(new Point(xx,yy));}p.Points.Add(new Point(w,h));p.Points.Add(new Point(0,h));c.Children.Add(p);}break;
        default: double rad=m*(.16+l*.25);AddEllipse(c,cx-rad,cy-rad,rad*2,rad*2,Ink(0),.8);AddEllipse(c,cx-rad*.78,cy-rad*.78,rad*1.56,rad*1.56,Color.FromRgb(8,8,23),1);for(int i=0;i<64;i++){double a=i*Math.PI/32,r1=rad*.92,r2=r1+b[i]*rad*.8;var line=new Line{X1=cx+Math.Cos(a)*r1,Y1=cy+Math.Sin(a)*r1,X2=cx+Math.Cos(a)*r2,Y2=cy+Math.Sin(a)*r2,Stroke=new SolidColorBrush(Ink(i/22)),StrokeThickness=2};c.Children.Add(line);}break;}
    }
    static void AddRect(Canvas c,double x,double y,double w,double h,Color color,double opacity,double radius,bool transparent=false){var s=new Rectangle{Width=w,Height=h,RadiusX=radius,RadiusY=radius,Fill=transparent?Brushes.Transparent:new SolidColorBrush(color),Stroke=transparent?new SolidColorBrush(color):null,StrokeThickness=2,Opacity=opacity};Canvas.SetLeft(s,x);Canvas.SetTop(s,y);c.Children.Add(s);}
    static void AddEllipse(Canvas c,double x,double y,double w,double h,Color color,double opacity,double stroke=0){var s=new Ellipse{Width=w,Height=h,Fill=stroke>0?Brushes.Transparent:new SolidColorBrush(color),Stroke=stroke>0?new SolidColorBrush(color):null,StrokeThickness=stroke,Opacity=opacity};Canvas.SetLeft(s,x);Canvas.SetTop(s,y);c.Children.Add(s);}
}
