package com.aurora.visualiser

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.core.app.ActivityCompat
import kotlin.math.*
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var visual: VisualView
    private lateinit var status: TextView
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    @Volatile private var running = false
    @Volatile private var level = 0f
    @Volatile private var bands = FloatArray(64)
    private var sensitivity = 1.6f
    private var palette = 0
    private var scene = 0
    private var previousScene = 0
    private var sceneMode = 0 // 0 locked, 1 random fade, 2 shuffle once
    private var transitionStarted = 0L
    private var transitionDurationMs = 4000L
    private var sceneIntervalMs = 60000L
    private val mainHandler = Handler(Looper.getMainLooper())
    private val sceneHandler = Handler(Looper.getMainLooper())
    private val rotationTask = object : Runnable {
        override fun run() {
            if (sceneMode == 1) {
                previousScene = scene
                val allowed = includedScenes.indices.filter { includedScenes[it] }
                if (allowed.isEmpty()) { status.text = "Choose at least one scene for random rotation"; sceneHandler.removeCallbacks(this); return }
                val choices = allowed.filter { it != scene }
                scene = if (choices.isNotEmpty()) choices[Random.nextInt(choices.size)] else allowed.first()
                transitionStarted = System.currentTimeMillis()
                visual.invalidate()
                sceneHandler.postDelayed(this, sceneIntervalMs + transitionDurationMs)
            }
        }
    }
    private val palettes = arrayOf("Aurora", "Sunset", "Ice", "Candy", "Monochrome")
    private val includedScenes = BooleanArray(8) { true }
    private val scenes = arrayOf("Neon Spectrum", "Cosmic Rings", "Aurora", "Oscilloscope", "Particle Storm", "Neon Tunnel", "Liquid Dreams", "Pulse")
    private val requestCode = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(7,7,17)); setPadding(18, 18, 18, 12) }
        val title = TextView(this).apply { text = "A U R O R A"; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; letterSpacing = .18f }
        val sub = TextView(this).apply { text = "AUDIO VISUALISER"; textSize = 11f; setTextColor(Color.rgb(155,145,190)); gravity = Gravity.CENTER; setPadding(0,2,0,12); letterSpacing = .2f }
        visual = VisualView(this)
        root.addView(title); root.addView(sub)
        root.addView(visual, LinearLayout.LayoutParams(-1, 0, 1f))
        val sceneLabel = label("SCENE")
        root.addView(sceneLabel)
        val sceneSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, scenes) ; setSelection(0); onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}; override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, position: Int, id: Long) { if (scene != position) { previousScene = scene; scene = position; transitionStarted = System.currentTimeMillis() }; visual.invalidate() } } }
        root.addView(sceneSpinner)
        val includeButton = Button(this).apply { text = "CHOOSE SCENES FOR RANDOM ROTATION"; setOnClickListener { showSceneFilter() } }
        root.addView(includeButton)
        root.addView(label("SCENE MODE"))
        val modeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Locked scene", "Random fade", "Shuffle once"))
            onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, position: Int, id: Long) {
                    sceneMode = position
                    sceneHandler.removeCallbacks(rotationTask)
                    if (position == 1) sceneHandler.postDelayed(rotationTask, sceneIntervalMs)
                    if (position == 2) shuffleOnce()
                }
            }
        }
        root.addView(modeSpinner)
        root.addView(label("TIME BETWEEN SCENE CHANGES · 10 SECONDS–5 MINUTES"))
        val intervalBar = SeekBar(this).apply {
            max = 290; progress = 50
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { sceneIntervalMs = (10L + p) * 1000L }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(intervalBar)
        root.addView(label("CROSSFADE DURATION · 1–10 SECONDS"))
        val fadeBar = SeekBar(this).apply {
            max = 9; progress = 3
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { transitionDurationMs = (p + 1L) * 1000L }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(fadeBar)
        root.addView(label("SENSITIVITY"))
        val sensitivityBar = SeekBar(this).apply { max = 300; progress = 160; setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { sensitivity = .2f + p / 100f }; override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} }) }
        root.addView(sensitivityBar)
        root.addView(label("COLOUR PALETTE"))
        val paletteSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, palettes); onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}; override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, position: Int, id: Long) { palette = position; visual.invalidate() } } }
        root.addView(paletteSpinner)
        val start = Button(this).apply { text = "START AUDIO VISUALISATION"; setOnClickListener { startCapture() } }
        root.addView(start, LinearLayout.LayoutParams(-1, -2))
        status = TextView(this).apply { text = "Ready · Choose music in another app, then start"; textSize = 11f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0,8,0,0) }
        root.addView(status)
        setContentView(root)
    }

    private fun showSceneFilter() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Scenes included in random rotation")
            .setMultiChoiceItems(scenes, includedScenes) { _, which, checked -> includedScenes[which] = checked }
            .setPositiveButton("Done", null)
            .show()
    }

    private fun shuffleOnce() {
        val allowed = includedScenes.indices.filter { includedScenes[it] }
        if (allowed.isEmpty()) { status.text = "Choose at least one scene for shuffle"; return }
        previousScene = scene
        val choices = allowed.filter { it != scene }
        scene = if (choices.isNotEmpty()) choices[Random.nextInt(choices.size)] else allowed.first()
        transitionStarted = System.currentTimeMillis()
        visual.invalidate()
    }

    private fun label(s: String) = TextView(this).apply { text = s; textSize = 10f; setTextColor(Color.rgb(165,155,200)); setPadding(2,10,0,0); letterSpacing = .12f }

    private fun startCapture() {
        if (running) { stopCapture(); return }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 4101); return
        }
        status.text = "Allow the Android audio-capture prompt to continue…"
        startActivityForResult(projectionManager.createScreenCaptureIntent(), requestCode)
    }

    @Deprecated("Android MediaProjection consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != this.requestCode || resultCode != RESULT_OK || data == null) { status.text = "Audio capture was not started"; return }
        try {
            projection = projectionManager.getMediaProjection(resultCode, data)
            val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
            val config = android.media.AudioPlaybackCaptureConfiguration.Builder(projection!!).addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME).build()
            val min = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            recorder = AudioRecord.Builder().setAudioFormat(format).setBufferSizeInBytes(max(min, 16384)).setAudioPlaybackCaptureConfig(config).build()
            recorder!!.startRecording(); running = true; status.text = "Listening to capturable internal audio · No microphone"
            Thread { analyseLoop() }.start()
        } catch (e: Exception) { status.text = "Could not start capture: ${e.message ?: "unsupported audio"}"; stopCapture() }
    }

    private fun analyseLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val buffer = ShortArray(2048)
        while (running) {
            val n = recorder?.read(buffer, 0, buffer.size) ?: -1
            if (n > 0) {
                var sum = 0.0
                val count = min(n, 1024)
                for (i in 0 until count) { val v = buffer[i] / 32768.0; sum += v*v }
                val rms = sqrt(sum / max(1,count)).toFloat()
                level = (rms * sensitivity * 7f).coerceIn(0f, 1f)
                val next = FloatArray(64)
                for (b in 0 until 64) {
                    val start = b * n / 64; val end = max(start + 1, (b + 1) * n / 64)
                    var peak = 0f
                    for (i in start until min(end,n)) peak = max(peak, abs(buffer[i].toFloat()/32768f))
                    next[b] = (peak * sensitivity * 5f).coerceIn(0f,1f)
                }
                bands = next
                runOnUiThread { visual.invalidate() }
            }
        }
    }

    private fun stopCapture() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release(); recorder = null
        projection?.stop(); projection = null
        level = 0f; bands = FloatArray(64)
        if (::status.isInitialized) status.text = "Stopped · No audio is saved"
        if (::visual.isInitialized) visual.invalidate()
    }
    override fun onDestroy() { sceneHandler.removeCallbacksAndMessages(null); stopCapture(); super.onDestroy() }

    inner class VisualView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val random = Random(14)
        private val particles = Array(110) { floatArrayOf(random.nextFloat(), random.nextFloat(), random.nextFloat() * 2 + .3f) }
        private val colors = arrayOf(
            intArrayOf(Color.rgb(65,245,210), Color.rgb(126,85,255), Color.rgb(255,75,190)),
            intArrayOf(Color.rgb(255,90,75), Color.rgb(255,190,65), Color.rgb(190,65,130)),
            intArrayOf(Color.rgb(80,210,255), Color.rgb(175,235,255), Color.rgb(100,120,255)),
            intArrayOf(Color.rgb(255,70,190), Color.rgb(130,90,255), Color.rgb(60,230,245)),
            intArrayOf(Color.WHITE, Color.LTGRAY, Color.GRAY)
        )
        private fun color(i: Int): Int = colors[palette][i % 3]
        override fun onDraw(c: Canvas) {
            super.onDraw(c); val w = width.toFloat(); val h = height.toFloat(); c.drawColor(Color.rgb(7,7,17))
            val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = RadialGradient(w/2,h/2,min(w,h)*.65f, color(1), Color.TRANSPARENT, Shader.TileMode.CLAMP) }
            c.drawRect(0f,0f,w,h,glow)
            val elapsed = System.currentTimeMillis() - transitionStarted
            val t = if (transitionStarted > 0L) (elapsed.toFloat() / transitionDurationMs).coerceIn(0f, 1f) else 1f
            if (t < 1f) {
                val oldLayer = c.saveLayerAlpha(0f, 0f, w, h, ((1f - t) * 255).toInt())
                drawScene(c, w, h, previousScene)
                c.restoreToCount(oldLayer)
                val newLayer = c.saveLayerAlpha(0f, 0f, w, h, (t * 255).toInt())
                drawScene(c, w, h, scene)
                c.restoreToCount(newLayer)
            } else drawScene(c, w, h, scene)
            if (running && level < .01f) { paint.color = Color.argb(160,220,220,240); paint.textSize = 12f; paint.textAlign = Paint.Align.CENTER; c.drawText("PLAY AUDIO IN ANOTHER APP",w/2,h-22,paint) }
            postInvalidateDelayed(33)
        }
        private fun drawScene(c: Canvas, w: Float, h: Float, which: Int) {
            when(which) {
                0 -> bars(c,w,h)
                1 -> rings(c,w,h)
                2 -> aurora(c,w,h)
                3 -> wave(c,w,h)
                4 -> particles(c,w,h)
                5 -> tunnel(c,w,h)
                6 -> liquid(c,w,h)
                else -> pulse(c,w,h)
            }
        }
        private fun bars(c:Canvas,w:Float,h:Float) { val gap=3f; val bw=(w-50)/64f; for(i in 0 until 64){ val v=bands[i]; val bh=max(3f,v*h*.72f); paint.color=color(i/22); paint.setShadowLayer(18f,0f,0f,color(i/22)); c.drawRoundRect(25+i*(bw+gap),h-bh-35,25+i*(bw+gap)+bw,h-35,5f,5f,paint); paint.clearShadowLayer() } }
        private fun rings(c:Canvas,w:Float,h:Float) { val cx=w/2; val cy=h/2; for(r in 0..5){ val idx=r*10; val rad=min(w,h)*(.12f+r*.065f)+bands[idx]*35; paint.style=Paint.Style.STROKE; paint.strokeWidth=2f+bands[idx]*3; paint.color=color(r); paint.setShadowLayer(16f,0f,0f,color(r)); c.drawCircle(cx,cy,rad,paint); paint.clearShadowLayer() }; paint.style=Paint.Style.FILL }
        private fun aurora(c:Canvas,w:Float,h:Float) { for(k in 0..3){ val p=Path(); for(x in 0..80){ val xx=x*w/80; val bi=(x*64/81).coerceIn(0,63); val yy=h*.48f+sin(x*.12+k*1.3)*h*.12f+cos(x*.055+k)*h*.08f-bands[bi]*h*.16f+k*22; if(x==0)p.moveTo(xx,yy) else p.lineTo(xx,yy) }; paint.style=Paint.Style.STROKE; paint.strokeWidth=15f; paint.color=color(k); paint.alpha=100; paint.setShadowLayer(25f,0f,0f,color(k)); c.drawPath(p,paint); paint.clearShadowLayer(); paint.alpha=255 }; paint.style=Paint.Style.FILL }
        private fun wave(c:Canvas,w:Float,h:Float) { val p=Path(); for(x in 0..w.toInt() step 3){ val i=(x*64/w).toInt().coerceIn(0,63); val y=h/2+sin(x*.045)*bands[i]*h*.38f+sin(x*.012)*h*.05f; if(x==0)p.moveTo(x.toFloat(),y) else p.lineTo(x.toFloat(),y) }; paint.style=Paint.Style.STROKE; paint.strokeWidth=3.5f; paint.color=color(0); paint.setShadowLayer(20f,0f,0f,color(0)); c.drawPath(p,paint); paint.clearShadowLayer(); paint.style=Paint.Style.FILL }
        private fun particles(c:Canvas,w:Float,h:Float) { val cx=w/2; val cy=h/2; particles.forEachIndexed { i,p -> val a=i*.31f+p[1]*6; val r=(.08f+p[0]*.38f+level*.35f)*min(w,h); val x=cx+cos(a)*r; val y=cy+sin(a)*r; paint.color=color(i/37); paint.alpha=150+(p[2]*40).toInt().coerceIn(0,100); c.drawCircle(x,y,1.5f+bands[i%64]*5,paint) } }
        private fun tunnel(c:Canvas,w:Float,h:Float) { val cx=w/2; val cy=h/2; for(i in 0..13){ val s=1f+i*.12f+level*.15f; val rw=w*.12f*s; val rh=h*.12f*s; paint.style=Paint.Style.STROKE; paint.strokeWidth=2f; paint.color=color(i); paint.alpha=220-i*10; c.drawRect(cx-rw,cy-rh,cx+rw,cy+rh,paint) }; paint.style=Paint.Style.FILL }
        private fun liquid(c:Canvas,w:Float,h:Float) { for(k in 0..2){ val p=Path(); p.moveTo(0f,h*.5f); for(x in 0..100){ val xx=x*w/100; val bi=(x*64/101).coerceIn(0,63); val yy=h*.5f+sin(x*.07+k*2)*h*.13f+cos(x*.025+k)*h*.08f-bands[bi]*h*.2f; p.lineTo(xx,yy) }; p.lineTo(w,h); p.lineTo(0f,h); p.close(); paint.color=color(k); paint.alpha=65; c.drawPath(p,paint); paint.alpha=255 } }
        private fun pulse(c:Canvas,w:Float,h:Float) { val rad=min(w,h)*(.16f+level*.25f); paint.color=color(0); paint.setShadowLayer(30f,0f,0f,color(0)); c.drawCircle(w/2,h/2,rad,paint); paint.clearShadowLayer(); paint.color=Color.rgb(7,7,17); c.drawCircle(w/2,h/2,rad*.78f,paint); paint.style=Paint.Style.STROKE; paint.strokeWidth=2f; for(i in 0..63){ val a=i*PI/32; val v=bands[i]; val r1=rad*.92f; val r2=r1+v*rad*.8f; paint.color=color(i/22); c.drawLine(w/2+cos(a).toFloat()*r1,h/2+sin(a).toFloat()*r1,w/2+cos(a).toFloat()*r2,h/2+sin(a).toFloat()*r2,paint) }; paint.style=Paint.Style.FILL }
    }
}
