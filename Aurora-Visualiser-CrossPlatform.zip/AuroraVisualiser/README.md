# Aurora Visualiser — Android + Windows

Aurora is a local, offline audio visualiser project with eight scenes, five palettes, sensitivity control, manual scene lock, one-shot shuffle, and automatic random scene rotation with configurable crossfades.

## Shared features

- Neon Spectrum, Cosmic Rings, Aurora, Oscilloscope, Particle Storm, Neon Tunnel, Liquid Dreams, and Pulse.
- Sensitivity and five colour palettes: Aurora, Sunset, Ice, Candy, Monochrome.
- Scene modes: Locked scene, Random fade, Shuffle once.
- Choose which scenes are eligible for random rotation.
- Random rotation interval: 10 seconds to 5 minutes.
- Crossfade duration: 1 to 10 seconds.
- Audio capture continues while scenes transition; transitions do not restart capture.
- No account, API key, subscription, cloud service, or audio upload.

## Android build

Open the `AuroraVisualiser` folder in Android Studio with JDK 17 and Android SDK 35. Let Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Minimum Android version: Android 10 (API 29).

Audio source: Android AudioPlaybackCapture (Android 10+), not the microphone. The app requires the Android `RECORD_AUDIO` permission and the system MediaProjection confirmation. Android playback capture is not universal: the source app must permit capture and use a supported audio usage. Some protected streaming apps opt out and will provide silence. This is an Android platform restriction that this app cannot bypass.

## Windows build

Open `WindowsAurora/WindowsAurora.csproj` in Visual Studio 2022 with the **.NET 8 Desktop Development** workload, or build from a Developer PowerShell:

```powershell
dotnet restore .\WindowsAurora\WindowsAurora.csproj
dotnet build .\WindowsAurora\WindowsAurora.csproj -c Release
```

The Windows version uses WASAPI loopback capture through NAudio. It captures the selected Windows playback endpoint, not the microphone. NuGet restore is needed for the NAudio dependency on the first build; after restore, capture and visualisation run locally. Windows privacy settings, endpoint/device availability, and exclusive-mode audio applications may affect capture.

## Important project status

This ZIP contains the source projects, not prebuilt APK/EXE installers. The current environment does not have the Android or Windows build toolchains installed, so the projects have not been compiled or tested on physical devices here. Build and test on Android Studio / Windows before distributing. The Android project includes a GitHub Actions APK workflow.
