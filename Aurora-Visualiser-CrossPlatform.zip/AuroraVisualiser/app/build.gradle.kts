plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aurora.visualiser"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aurora.visualiser"
        minSdk = 29
        targetSdk = 33
        versionCode = 2
        versionName = "1.1"
    }
}
